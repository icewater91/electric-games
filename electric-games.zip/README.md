# Electric Games

# About

This is a web application that displays Games and give access to the users basic information about it like The name, platform, releasedYear,
Description and Image. It allows user to edit / delete Games they wish.

## Features

- Data base of all the Games created
- Ability to Edit a Games
- Ability to Delete a Game
- Animation on scroll
- Responsive layout
- Keyboard navigation

### The project is build with

- HTML5
- CSS3
- Typescript
- Vite
- CSS Flexbox
- CSS Grid
- Sanity Studio
- Query language GROQ
- Figma

## Process

### Minimum Viable Product (MVP)

The MVP for this project was a web application which contains header, footer, displays accommodations with information, and has ability to filter accommodations by property type, county name and the number of beds.

![MVP](/_app/assets/images/mvp.jpeg)

In the images below you can se the project planning process.

![Screenshot of the GitHub project](/_app/assets/images/github_project_first.jpeg)
![Screenshot of the GitHub project](/_app/assets/images/github_project_second.jpeg)
![Screenshot of the GitHub project](/_app/assets/images/github_project_third.jpeg)

### Data base model

The database consists of three documents: accommodation, county and information about us. In the accommodation scheme, when choosing a region, we refer to the document county. In order to see the database model in more detail, I have attached an image of the database diagram.

![Data base model](/_app/assets/images/data_base_model.jpeg)

## Access

`http://localhost:5500`
`http://localhost:3333`

## Links

- Project: https://github.com/users/SergeiRavinski/projects/5
- Projects repository: https://github.com/SergeiRavinski/SREiendom
- Live demo: https://sreiendom.netlify.app
